package hive.conn.example;

import java.sql.*;

public class HDInsightHiveJdbc {
  public static void main(String[] args) throws SQLException {


    //Assume that the arguments are in correct order
    String clusterName = "mycluster87";
    String clusterAdmin = "admin";
    String clusterPassword = "Spzx1k74!!";

    //Variables to hold statements, connection, and results
    Connection conn=null;
    Statement stmt = null;
    ResultSet res = null;

    try
    {
      //Load the HiveServer2 JDBC driver
      Class.forName("org.apache.hive.jdbc.HiveDriver");

      //Create the connection string
      // Note that HDInsight always uses the external port 443 for SSL secure
      //  connections, and will direct it to the hiveserver2 from there
      //  to the internal port 10001 that Hive is listening on.
      String connectionQuery = String.format(
        "jdbc:hive2://%s.azurehdinsight.net:443/default;ssl=true?hive.server2.transport.mode=http;hive.server2.thrift.http.path=/hive2",
        clusterName);

      //Get the connection using the cluster admin user and password
      conn = DriverManager.getConnection(connectionQuery,clusterAdmin,clusterPassword);
 
      //Retrieve data from the table
      String sql = "SELECT * from Climate LIMIT 5";
      stmt = conn.createStatement();
      System.out.println("\nRetrieving data:");

      res = stmt.executeQuery(sql);

      while (res.next()) {
        System.out.println("Column0 => "+res.getString("column0"));
      }
      System.out.println("\nHive queries completed successfully!");
    }

    //Catch exceptions
    catch (SQLException e )
    {
      e.getMessage();
      e.printStackTrace();
      System.exit(1);
    }
    catch(Exception ex)
    {
      ex.getMessage();
      ex.printStackTrace();
      System.exit(1);
    }
    //Close connections
    finally {
      if (res!=null) res.close();
      if (stmt!=null) stmt.close();
    }
  }
}
