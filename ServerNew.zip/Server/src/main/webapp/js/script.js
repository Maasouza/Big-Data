var mandarRequest = function () {
    var e = document.getElementById("selectTipo");
    var tp = e.options[e.selectedIndex].value;
    var data = {
        "station": document.getElementById("pais").value,
        "opcao": tp,
        "dateI": document.getElementById("dataI").value,
        "dateF": document.getElementById("dataF").value
    }
    var objPedidoAJAX = new XMLHttpRequest();
    objPedidoAJAX.open("POST", "http://localhost:8084/Trab2/controller");
    objPedidoAJAX.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    // Prepara recebimento da resposta: tipo da resposta JSON!
    objPedidoAJAX.responseType = 'json';
    objPedidoAJAX.onreadystatechange =
            function () {
                if (objPedidoAJAX.readyState === 4 && objPedidoAJAX.status === 200) {
                    drawChart(objPedidoAJAX.response.resultado,objPedidoAJAX.response.tipo )
                    //alert(objPedidoAJAX.response.alert);
                }else{
                    voltar()
                }
            };
    // Envio do pedido

    objPedidoAJAX.send(JSON.stringify(data));

};
